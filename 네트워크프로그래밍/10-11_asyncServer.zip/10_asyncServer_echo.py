# 비동기 에코 서버
import asyncio

HOST = '127.0.0.1'
PORT = 5000

async def handle_client(reader, writer):
    addr = writer.get_extra_info('peername')
    print('연결:', addr)
    try:
        while True:
            data = await reader.readline()       # '\n'까지 한 줄 올 때까지 대기
            if not data:                         # 클라이언트가 연결을 닫음
                break
            print('수신:', data.decode().rstrip())  # right 여백 strip
            writer.write(data)                   # 받은 그대로 돌려줌
            await writer.drain()                 # 전송 버퍼가 비워질 때까지 대기
    except ConnectionError:
        pass
    finally:
        writer.close()
        await writer.wait_closed()
        print('종료:', addr)

async def main():
    server = await asyncio.start_server(handle_client, HOST, PORT)
    print('대기 (Ctrl+C로 종료)')
    async with server:
        await server.serve_forever()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('\n서버 종료')